import dash
from dash import html
import pandas as pd
import plotly.express as px

# Carregar o CSV
df = pd.read_csv('filmes_adorocinema.csv')

# Ordernar filmes pelas notas
df = df.sort_values(by = 'Nota', ascending=True)

# Criar o gráfico com plotly
fig = px.bar(
    df, 
    x = 'Nota', 
    y = 'Título',
    orientation='h',
    labels={'nota':'Nota dos Filmes','Título:':'Titulo do Filme'},
    title= 'Notas dos Filmes'
)

# Inicializando a aplicação Dash
app = dash.Dash()

# Difinindo o layout da aplicação
app.layout = html.Div([
    html.H1("Gráfico de Notas dos Filmes", style={'text-align':'Center'}),
    html.Div([
        html.Iframe(
            srcDoc = fig.to_html(),
            width = '100%',
            height = '600px',
            style = {'border':'none'}
        )
        
    ], style = {'padding':'15px'})
])

if __name__ == '__main__':
    app.run(debug=True)
# Importa o algoritmo de clustering do kmeans da biblioteca scikit-learn
from sklearn.cluster import KMeans
# Importa o escalador StandardScaler para padronizar os dados
from sklearn.preprocessing import StandardScaler

# Definir os dados de exemplo
# Será uma lista de listas

x = [[1,2],[1,2],[1,2],[1,2],[1,2],[10,20]]

# Vamos instanciar o Standard para padronizar os dados
scaler = StandardScaler()

# Aplicar o escalador nos dados para que tenham média 0 e desvio padrão 1
x_scaled = scaler.fit_transform(x)

# Cria a instância do algoritmo do KMeans com 2 clusters
kmeans = KMeans(n_clusters=2, random_state=42)

# Aplicar i algoritmo do KMeans aos dados padronizaddos
kmeans.fit(x_scaled)

# Exibir os rótulos (clusters) atribuídos a cada ponto

print (kmeans.labels_)



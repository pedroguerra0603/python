import dash
from dash import dcc, html
from dash.dependencies import Input, Output 
import plotly.graph_objs as go

# Dicionário com as Informações da Caixa Dropdown
dados_conceitos = {
    'Java': {'Variaveis':8, 'Condicionais':10, 'Loops':4, 'POO':3, 'Funções':6},
    'Python': {'Variaveis':9, 'Condicionais':8, 'Loops':5, 'POO':4, 'Funções':7},
    'SQL': {'Variaveis':10, 'Condicionais':2, 'Loops':6, 'POO':5, 'Funções':8},
    'GoLang': {'Variaveis':7, 'Condicionais':1, 'Loops':7, 'POO':6, 'Funções':9},
    'JavaScript': {'Variaveis':6, 'Condicionais':3, 'Loops':8, 'POO':7, 'Funções':10}
}

cores_map = dict(
    Java = 'red',
    Python = 'green',
    SQL = 'yellow',
    GoLang = 'blue',
    JavaScript = 'pink'
)

app = dash.Dash(__name__)

app.layout = html.Div([
    html.H4('Cursos de TI', style={'textAlign':'center'}),
    html.Div(
        dcc.Dropdown(
            id = 'dropdown_linguagens',
            options = [
                {'label':'Java','value':'Java'},
                {'label':'Python','value':'Python'},
                {'label':'SQL','value':'SQL'},
                {'label':'GoLang','value':'GoLang'},
                {'label':'JavaScript','value':'JavaScript'}
            ],
            value = ['Java'],
            multi = True,
            style={'width':'50%', 'margin':'0 auto '}
        )
        
    ),
    dcc.Graph(id='grafico_linguagem')
], style = {'width':'80%', 'margin':'0 auto'}
)

# Uma função que vai ser chamada através do evento
@app.callback(
    Output('grafico_linguagem','figure'),
    [Input('dropdown_linguagens', 'value')]
)

def scarter_linguagens(linguagens_selecionadas):
    scarter_trace=[]
    for linguagem in linguagens_selecionadas:
        dados_linguagem = dados_conceitos[linguagem]
        for conceito, conhecimento in dados_linguagem.items():
            scarter_trace.append(
                go.Scatter(
                    x = [conceito],
                    y = [conhecimento],
                    mode = 'markers',
                    name = linguagem.title(),
                    marker = {'size':15,'color':cores_map[linguagem]},
                    showlegend = False
                )
            )
    scarter_layout = go.layout(
        title = 'Meus conhecimentos em Linguagens',
        xaxis = dict(title = 'Conceitos', showgrid=False),
        yaxis = dict(title = 'Niveis de Conhecimento', showgrid = False)
    )
    return {'data':scarter_trace, 'layout':scarter_layout}

if __name__ == '__main__':
    app.run(debug=True)